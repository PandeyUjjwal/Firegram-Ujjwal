import * as firebase from 'firebase/app';
import 'firebase/storage';
import 'firebase/firestore';

 // Import the functions you need from the SDKs you need
 //import {initializeApp} from "https://www.gstatic.com/firebasejs/9.8.1/firebase-app.js";
 // TODO: Add SDKs for Firebase products that you want to use
 // https://firebase.google.com/docs/web/setup#available-libraries

 // Your web app's Firebase configuration
 const firebaseConfig = {
   apiKey: "AIzaSyAtPiE1yf4GGNxjc8e8_Co-XxcKCqlqkRc",
   authDomain: "ujjwal-firegram.firebaseapp.com",
   projectId: "ujjwal-firegram",
   storageBucket: "ujjwal-firegram.appspot.com",
   messagingSenderId: "273599779044",
   appId: "1:273599779044:web:ee824dcdaa0d8a8feb9cf1"
 };

 // Initialize Firebase
 firebase.initializeApp(firebaseConfig);

const projectStorage = firebase.storage();
const projectFirestore = firebase.firestore();
const timestamp = firebase.firestore.FieldValue.serverTimestamp;

export { projectStorage, projectFirestore, timestamp };